# -*- coding: utf8 -*-

"""
Copyright (c) 2011 Jan Pomikalek

This software is licensed as described in the file LICENSE.rst.
"""

from __future__ import absolute_import

from .core import justext, get_stoplists, get_stoplist


__version__ = "2.1.1"
